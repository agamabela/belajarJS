//objek

let bela = {
    firstName: "Bela",
    lastName: "Agama",
    age: 27,
    job: "Coder"
}
console.table(bela)//memanggil objek
console.table(bela.job)

//syntax object 'new' keyboard
let depanlaptop = new Object()

depanlaptop.firstName = 'Belalabo'
depanlaptop.lastName = 'Belaboi'
depanlaptop.age = 27
depanlaptop.job = "Meteor"

console.table(depanlaptop)

let Ade = {}
Ade.firstName = 'Andi'
Ade.lastName = 'Ade'
console.log(Ade)